package com.example.myapplication.data.model;

public class Wind {
    public double speed;
    public int deg;
}

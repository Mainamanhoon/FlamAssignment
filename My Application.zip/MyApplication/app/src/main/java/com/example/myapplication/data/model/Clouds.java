package com.example.myapplication.data.model;

public class Clouds {
    public int all;
}

package com.example.myapplication.data.model;

public class Sys {
    public int type;
    public int id;
    public String country;
    public long sunrise;
    public long sunset;
}

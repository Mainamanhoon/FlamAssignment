package com.example.myapplication.data.model;

public class Coord {
    public double lon;
    public double lat;
}

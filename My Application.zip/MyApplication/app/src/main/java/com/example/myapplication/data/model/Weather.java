package com.example.myapplication.data.model;

public class Weather {
    public int id;
    public String main;
    public String description;
    public String icon;
}

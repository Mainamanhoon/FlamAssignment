package com.example.fireworksimulationusingopengl;

public class Particle {
    public float x, y;           // Position
    public float velocityX, velocityY; // Velocity
    public float r, g, b, alpha; // Color and transparency
    public float life;           // Remaining lifetime
    public float maxLife;        // Initial lifetime

    // Firework trail properties
    public boolean isTrailParticle; // Is this a trailing particle?
    public float explosionTimer;    // Time until explosion

    public Particle(float x, float y, float vx, float vy, float r, float g, float b, boolean isTrail) {
        this.x = x;
        this.y = y;
        this.velocityX = vx;
        this.velocityY = vy;
        this.r = r;
        this.g = g;
        this.b = b;
        this.alpha = 1.0f;
        this.isTrailParticle = isTrail;

        if (isTrail) {
            // Trail particle - longer life, explosion timer
            this.life = 5.0f;
            this.maxLife = this.life;
            this.explosionTimer = 1.0f + (float) Math.random() * 1.0f; // 1-2 seconds
        } else {
            // Explosion particle - normal life
            this.life = 2.0f + (float) Math.random() * 2.0f; // 2-4 seconds
            this.maxLife = this.life;
            this.explosionTimer = 0.0f;
        }
    }
}
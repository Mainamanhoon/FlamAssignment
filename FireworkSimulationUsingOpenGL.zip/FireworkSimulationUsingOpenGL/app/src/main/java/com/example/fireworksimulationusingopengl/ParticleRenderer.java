package com.example.fireworksimulationusingopengl;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class ParticleRenderer implements GLSurfaceView.Renderer {
    private final String vertexShaderCode =
            "attribute vec4 vPosition;" +
                    "attribute float vSize;" +
                    "attribute vec4 vColor;" +
                    "uniform mat4 uMVPMatrix;" +
                    "varying vec4 v_Color;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "  gl_PointSize = vSize;" +
                    "  v_Color = vColor;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "varying vec4 v_Color;" +
                    "void main() {" +
                    "  float dist = distance(gl_PointCoord, vec2(0.5));" +
                    "  if (dist > 0.5) discard;" +
                    "  float alpha = 1.0 - (dist * 2.0);" +
                    "  gl_FragColor = vec4(v_Color.rgb, v_Color.a * alpha);" +
                    "}";

    private int shaderProgram;
    private int positionHandle;
    private int sizeHandle;
    private int colorHandle;
    private int mvpMatrixHandle;

    private final float[] mvpMatrix = new float[16];
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];

    private List<Particle> particles;
    private FloatBuffer vertexBuffer;
    private FloatBuffer sizeBuffer;
    private FloatBuffer colorBuffer;

    private Random random;

    public ParticleRenderer() {
        particles = new ArrayList<>();
        random = new Random();
    }

    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

        // Enable blending for particle effects
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE); // Additive blending

        // Load and compile shaders
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        // Create shader program
        shaderProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(shaderProgram, vertexShader);
        GLES20.glAttachShader(shaderProgram, fragmentShader);
        GLES20.glLinkProgram(shaderProgram);

        // Get shader attribute and uniform locations
        positionHandle = GLES20.glGetAttribLocation(shaderProgram, "vPosition");
        sizeHandle = GLES20.glGetAttribLocation(shaderProgram, "vSize");
        colorHandle = GLES20.glGetAttribLocation(shaderProgram, "vColor");
        mvpMatrixHandle = GLES20.glGetUniformLocation(shaderProgram, "uMVPMatrix");
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        // Update particles
        updateParticles();

        // Draw particles
        drawParticles();
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES20.glViewport(0, 0, width, height);

        float ratio = (float) width / height;
        Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1, 1, 3, 7);
        Matrix.setLookAtM(viewMatrix, 0, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewMatrix, 0);
    }

    public void addParticleBurst(float x, float y) {
        synchronized (particles) {
            // Create 5-8 trailing particles that shoot upward
            int trailCount = 5 + random.nextInt(4);

            // Pick a random color for this firework
            float r = 0.3f + random.nextFloat() * 0.7f;
            float g = 0.3f + random.nextFloat() * 0.7f;
            float b = 0.3f + random.nextFloat() * 0.7f;

            for (int i = 0; i < trailCount; i++) {
                // Small horizontal spread, strong upward velocity
                float horizontalSpread = (random.nextFloat() - 0.5f) * 0.3f;
                float upwardVelocity = 1.2f + random.nextFloat() * 0.8f; // 1.2 to 2.0

                // Create trailing particle
                Particle trailParticle = new Particle(x, y, horizontalSpread, upwardVelocity, r, g, b, true);
                particles.add(trailParticle);
            }
        }
    }

    private void updateParticles() {
        float deltaTime = 0.016f; // Assume 60 FPS
        List<Particle> newExplosionParticles = new ArrayList<>();

        synchronized (particles) {
            Iterator<Particle> iterator = particles.iterator();
            while (iterator.hasNext()) {
                Particle particle = iterator.next();

                // Update position
                particle.x += particle.velocityX * deltaTime;
                particle.y += particle.velocityY * deltaTime;

                // Apply gravity
                particle.velocityY -= 2.0f * deltaTime;

                if (particle.isTrailParticle) {
                    // TRAIL PARTICLE - Check if it should explode
                    particle.explosionTimer -= deltaTime;

                    if (particle.explosionTimer <= 0.0f) {
                        // Time to explode! Create burst particles at this location
                        createExplosionAt(particle.x, particle.y, particle.r, particle.g, particle.b, newExplosionParticles);

                        // Remove this trail particle
                        iterator.remove();
                        continue;
                    }

                    // Trail particles stay bright
                    particle.alpha = 0.9f;
                } else {
                    // EXPLOSION PARTICLE - Normal fading behavior
                    particle.life -= deltaTime;
                    particle.alpha = Math.max(0.0f, particle.life / particle.maxLife);

                    // Remove dead particles
                    if (particle.life <= 0) {
                        iterator.remove();
                    }
                }
            }

            // Add all new explosion particles
            particles.addAll(newExplosionParticles);
        }
    }

    private void createExplosionAt(float x, float y, float r, float g, float b, List<Particle> explosionList) {
        // Create 40-80 explosion particles
        int explosionCount = 40 + random.nextInt(40);

        for (int i = 0; i < explosionCount; i++) {
            float angle = random.nextFloat() * 2.0f * (float) Math.PI;
            float speed = 0.6f + random.nextFloat() * 1.4f;

            float velocityX = (float) Math.cos(angle) * speed;
            float velocityY = (float) Math.sin(angle) * speed;

            // Create explosion particle (not a trail particle)
            Particle explosionParticle = new Particle(x, y, velocityX, velocityY, r, g, b, false);
            explosionList.add(explosionParticle);
        }
    }

    private void drawParticles() {
        int particleCount;
        float[] positions;
        float[] sizes;
        float[] colors;

        // Copy particle data inside synchronized block to minimize lock time
        synchronized (particles) {
            if (particles.isEmpty()) return;

            particleCount = particles.size();
            positions = new float[particleCount * 3];
            sizes = new float[particleCount];
            colors = new float[particleCount * 4];

            for (int i = 0; i < particleCount; i++) {
                Particle p = particles.get(i);

                // Position
                positions[i * 3] = p.x;
                positions[i * 3 + 1] = p.y;
                positions[i * 3 + 2] = 0.0f;

                // Size (varies with life)
                sizes[i] = 20.0f * p.alpha;

                // Color
                colors[i * 4] = p.r;
                colors[i * 4 + 1] = p.g;
                colors[i * 4 + 2] = p.b;
                colors[i * 4 + 3] = p.alpha;
            }
        }

        // Create buffers outside synchronized block
        vertexBuffer = createFloatBuffer(positions);
        sizeBuffer = createFloatBuffer(sizes);
        colorBuffer = createFloatBuffer(colors);

        // Use shader program
        GLES20.glUseProgram(shaderProgram);

        // Set MVP matrix
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0);

        // Set vertex attributes
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        GLES20.glEnableVertexAttribArray(sizeHandle);
        GLES20.glVertexAttribPointer(sizeHandle, 1, GLES20.GL_FLOAT, false, 0, sizeBuffer);

        GLES20.glEnableVertexAttribArray(colorHandle);
        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, 0, colorBuffer);

        // Draw particles as points
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, particleCount);

        // Disable vertex arrays
        GLES20.glDisableVertexAttribArray(positionHandle);
        GLES20.glDisableVertexAttribArray(sizeHandle);
        GLES20.glDisableVertexAttribArray(colorHandle);
    }

    private FloatBuffer createFloatBuffer(float[] data) {
        ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer buffer = bb.asFloatBuffer();
        buffer.put(data);
        buffer.position(0);
        return buffer;
    }

    private int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}
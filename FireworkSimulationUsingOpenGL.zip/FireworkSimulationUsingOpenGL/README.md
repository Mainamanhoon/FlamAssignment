# GPU-Accelerated Fireworks Particle System

An interactive Android application that simulates realistic firework explosions using OpenGL ES 2.0. Tap anywhere on the screen to launch fireworks with trailing particles that explode into spectacular bursts.

## 🎆 Features

- **Realistic Two-Stage Fireworks**: Trail particles shoot upward, then explode into burst patterns
- **GPU-Accelerated Rendering**: Uses OpenGL ES shaders for smooth performance
- **Interactive Touch Control**: Tap anywhere to launch fireworks at that location
- **Physics Simulation**: Gravity, air resistance, and particle lifecycle management
- **Visual Effects**: Additive blending, particle fading, and smooth animations
- **Multi-Firework Support**: Launch multiple fireworks simultaneously with staggered timing

## 🚀 How It Works

### Two-Phase Animation System

#### Phase 1: Trail Launch
1. **User taps screen** → 5-8 bright trail particles spawn at touch location
2. **Particles shoot upward** with slight horizontal spread
3. **Trail particles maintain brightness** and have a 1-2 second explosion timer
4. **Physics applied**: Upward velocity with gravity pulling them down

#### Phase 2: Explosion
1. **Timer expires** → Each trail particle triggers an explosion at its current position
2. **40-80 burst particles** spawn in all directions from the explosion point
3. **Radial velocity pattern** creates realistic firework burst
4. **Particles fade out** over time while falling with gravity

### Technical Architecture

#### Core Components

**MainActivity.java**
- Sets up OpenGL surface view
- Handles touch events and coordinate conversion
- Manages activity lifecycle

**ParticleRenderer.java**
- Implements GLSurfaceView.Renderer
- Manages OpenGL rendering pipeline
- Updates particle physics each frame
- Handles shader compilation and GPU communication

**Particle.java**
- Individual particle data structure
- Stores position, velocity, color, and lifecycle properties
- Distinguishes between trail and explosion particles

#### Graphics Pipeline

**Vertex Shader**
```glsl
- Transforms particle positions using MVP matrix
- Sets individual particle sizes
- Passes color information to fragment shader
```

**Fragment Shader**
```glsl
- Creates circular particle shape using gl_PointCoord
- Applies soft edge fadeout for smooth appearance
- Handles color and alpha blending
```

#### Physics Simulation

**Particle Movement**
- Position updated based on velocity each frame
- Gravity applied as downward acceleration
- Air resistance gradually slows particles

**Collision Detection**
- Particles removed when lifetime expires
- No inter-particle collision (performance optimization)

**Thread Safety**
- Synchronized particle list access between UI and render threads
- Prevents ConcurrentModificationException crashes

## 📱 Setup Instructions

### Prerequisites
- Android Studio (latest version)
- Android device or emulator with OpenGL ES 2.0 support
- Minimum SDK: API 21 (Android 5.0)
- Target SDK: API 34

### Installation Steps

1. **Clone or download** the project files
2. **Open in Android Studio**
3. **Update build.gradle** with the provided configuration
4. **Update AndroidManifest.xml** with OpenGL ES feature requirement
5. **Build and run** on device or emulator

### Required Files Structure
```
app/src/main/java/com/example/particlesystem/
├── MainActivity.java
├── ParticleRenderer.java
└── Particle.java
```

### Dependencies
```gradle
dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
}
```

## 🎮 Usage

1. **Launch the app** → Black screen with particle system ready
2. **Tap anywhere** → Trail particles shoot upward from tap location
3. **Wait 1-2 seconds** → Trails explode into colorful bursts
4. **Tap multiple times** → Create fireworks show with overlapping effects
5. **Enjoy the show!** → Particles fall and fade naturally

## ⚙️ Technical Details

### Performance Optimizations

**GPU Acceleration**
- All particles rendered as OpenGL point sprites
- Vertex buffer objects for efficient data transfer
- Minimal CPU-GPU communication per frame

**Memory Management**
- Dynamic particle creation and destruction
- Synchronized collections for thread safety
- Efficient float buffer allocation

**Rendering Efficiency**
- Additive blending for realistic light effects
- Point sprite rendering (no geometry generation)
- Batch rendering of all particles in single draw call

### Coordinate Systems

**Screen to OpenGL Conversion**
```java
// Convert touch coordinates to OpenGL space
float x = -((event.getX() / width) * 2.0f - 1.0f);  // -1 to +1
float y = -((event.getY() / height) * 2.0f - 1.0f); // -1 to +1 (inverted)
```

**Physics Units**
- Position: OpenGL normalized coordinates (-1 to +1)
- Velocity: Units per second
- Time: Seconds (60 FPS assumed)
- Gravity: -2.0 units/second²

### Shader Details

**Vertex Attributes**
- `vPosition`: 3D particle position (x, y, z)
- `vSize`: Particle size in pixels
- `vColor`: RGBA color values (0.0 to 1.0)

**Uniforms**
- `uMVPMatrix`: Model-View-Projection transformation matrix

## 🎨 Customization Options

### Particle Properties
```java
// In addParticleBurst() method
int trailCount = 5 + random.nextInt(4);        // Number of trail particles
float upwardVelocity = 1.2f + random.nextFloat() * 0.8f;  // Launch speed
float explosionTimer = 1.0f + random.nextFloat() * 1.0f;  // Explosion delay
```

### Visual Effects
```java
// In createExplosionAt() method
int explosionCount = 40 + random.nextInt(40);  // Burst particle count
float speed = 0.6f + random.nextFloat() * 1.4f; // Explosion velocity
```

### Colors and Appearance
```java
// Modify color generation in addParticleBurst()
float r = 0.3f + random.nextFloat() * 0.7f;  // Red component
float g = 0.3f + random.nextFloat() * 0.7f;  // Green component  
float b = 0.3f + random.nextFloat() * 0.7f;  // Blue component
```

## 🐛 Troubleshooting

**Black Screen Issues**
- Ensure OpenGL ES 2.0 is supported on device
- Check shader compilation errors in logs
- Verify proper surface view setup

**Touch Coordinate Problems**
- Coordinate conversion handles screen orientation
- Test on different screen resolutions
- Check for proper event handling

**Performance Issues**
- Reduce particle counts for older devices
- Monitor frame rate in GPU profiler
- Consider reducing particle lifetime

## 📚 Learning Resources

This project demonstrates:
- **OpenGL ES 2.0 fundamentals**
- **Shader programming (GLSL)**
- **Particle system design**
- **Android graphics programming**
- **Real-time physics simulation**
- **Thread-safe programming**

## 🔧 Future Enhancements

- **Particle textures** for more realistic effects
- **Sound effects** synchronized with explosions
- **Multiple firework types** (chrysanthemum, peony, etc.)
- **Wind effects** and air resistance variations
- **Particle pooling** for better memory management
- **VBO instancing** for higher particle counts

## 📄 License

This project is for educational purposes. Feel free to use and modify for learning OpenGL ES and Android graphics programming.

---

**Created for Android Graphics Programming Assignment**  
*Demonstrates GPU-accelerated particle systems using OpenGL ES 2.0*